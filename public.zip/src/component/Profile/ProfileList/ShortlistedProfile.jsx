import React, { useEffect, useState } from "react";
import "./ShortListedProfile.css";
import ProfileCard from "./ProfileCard";
import { FaChevronDown } from "react-icons/fa";
import placeholderImage from "../../../assets/images/blurimage.png";
import { useAuth } from "../../Layout/AuthContext";

export function RequestImageContainer({ profile }) {
  const photos = profile?.filesId?.photos || [];

  // If no photos are available, show a placeholder with request action
  if (photos.length === 0) {
    return (
      <div className="image-container">
        <img src={placeholderImage} alt="profile" className="profileImage" />
      </div>
    );
  }

  return (
    <div className="image-container">
      {photos.map((photo, index) => (
        <img
          key={photo?._id || index}
          src={photo?.url || placeholderImage}
          className={`profileImage`}
          alt="Profile"
        />
      ))}
    </div>
  );
}

const ShortlistedProfile = () => {
  const { fetchUserData, updateData } = useAuth();
  const [sortCriteria, setSortCriteria] = useState("");
  const [profiles, setProfiles] = useState([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);

  const sortProfiles = (criteria) => {
    if (!Array.isArray(profiles)) {
      setError("Profiles data is not in the correct format.");
      return;
    }

    let sortedProfiles = [...profiles];
    if (criteria === "age") {
      sortedProfiles = sortedProfiles.sort((a, b) => a.age - b.age);
    } else if (criteria === "height") {
      sortedProfiles = sortedProfiles.sort((a, b) => a.height - b.height);
    }
    setProfiles(sortedProfiles);
    setSortCriteria(criteria); // Update sort criteria
  };

  const fetchData = async () => {
    try {
      const route = "profile/show-shortlisted";
      let data = await fetchUserData(route);

      if (!data || !Array.isArray(data.shortlisted)) {
        setError("Invalid data format");
        return;
      }

      setProfiles(data.shortlisted);
    } catch (err) {
      console.error(err);
      setError(
        err.message || "An unexpected error occurred while fetching profiles."
      );
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id) => {
    if (!Array.isArray(profiles)) return;
    let route = "profile/shortlisted/delete";
    await updateData(route, id);
    fetchData();
  };

  useEffect(() => {
    fetchData();
  }, []);

  if (loading) {
    return (
      <div className="profileContainer">
        <div className="profileListHeader">
          <div className="pagetitle">Short Listed Profiles</div>
        </div>
        <div
          className="d-flex justify-content-center align-items-center"
          style={{ height: "200px" }}
        >
          <div className="spinner-border text-primary" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        </div>
      </div>
    );
  }

  if (!Array.isArray(profiles) || profiles.length === 0) {
    return (
      <div className="profileContainer">
        <div className="profileListHeader">
          <div className="pagetitle">Short Listed Profiles</div>
        </div>
        <div className="pagetitle text-center">No Profiles Found</div>
      </div>
    );
  }

  return (
    <div className="profileContainer">
      <div className="profileListHeader">
        <div className="pagetitle">Short Listed Profiles</div>
        <div className="filters">
          <div
            className="filterItem d-flex justify-content-between"
            onClick={() => sortProfiles("age")}
          >
            <span>Age</span>
            <span>
              <FaChevronDown />
            </span>
          </div>
          <div
            className="filterItem d-flex justify-content-between"
            onClick={() => sortProfiles("height")}
          >
            <span>Height</span>
            <span>
              <FaChevronDown />
            </span>
          </div>
        </div>
      </div>

      {profiles.map((element) => (
        <ProfileCard
          key={element._id}
          element={element}
          handleDelete={handleDelete}
          ProfileImagerender={RequestImageContainer}
        />
      ))}
    </div>
  );
};

export default ShortlistedProfile;
