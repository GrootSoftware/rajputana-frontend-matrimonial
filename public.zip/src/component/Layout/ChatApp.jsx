import React, { useState, useEffect } from "react";
// import io from "socket.io-client";
// import axios from "axios";
// // Styles and Components
// import style from "../Profile/ProfileComp/Profile.module.css";
// import Profilenavbar from "../Profile/ProfileComp/Profilenavbar";
// import Footer from "./Footer";
// import { AiOutlineRight, AiOutlineClose } from "react-icons/ai";

// import styles from "../Profile/Forms/Form.module.css";

// const socket = io("http://localhost:5000", { autoConnect: false });

const ChatApp = () => {
//   const [messages, setMessages] = useState([]);
//   const [message, setMessage] = useState("");
//   const [chats, setChats] = useState([]);
//   const [activeChat, setActiveChat] = useState(null);
//   const [error, setError] = useState(null);

//   useEffect(() => {
//     socket.connect();

//     socket.on("newMessage", (newMessage) => {
//       setMessages((prev) => [...prev, newMessage]);
//     });

//     return () => {
//       socket.off("newMessage");
//       socket.disconnect();
//     };
//   }, []);

//   const loadMessages = async (chatId) => {
//     setActiveChat(chatId);
//     try {
//       const response = await axios.get(
//         `http://localhost:5000/chat/${chatId}/messages`
//       );
//       setMessages(response.data);
//     } catch (err) {
//       setError("Unable to load messages");
//     }
//   };

//   const sendMessage = async () => {
//     if (message.trim() && activeChat) {
//       try {
//         const data = { sender: activeChat, message: message };
//         await axios.post("http://localhost:5000/message/send", data);
//         setMessage("");
//       } catch (error) {
//         setError("Failed to send message");
//       }
//     }
//   };

//   return (
//     <>
//       <div className={style.minhScreen}>
//         <Profilenavbar />
//         <div className={style.Container}>
//           {/* Breadcrumb Navigation */}
//           <div className={style.routerpathtext}>
//             {"Home "} <AiOutlineRight /> {" Success Stories"}
//           </div>

//           <section className="flex flex-1 overflow-hidden">
//             <div className="w-1/3 bg-white border-r border-gray-300 overflow-y-auto">
//               <div className="p-4 border-b border-gray-300">
//                 <input
//                   type="text"
//                   placeholder="Search"
//                   className="w-full p-2 border border-gray-300 rounded"
//                 />
//               </div>
//               <div className="p-4">
//                 {chatList.map((chat) => (
//                   <div
//                     key={chat.id}
//                     className="mb-4 cursor-pointer"
//                     onClick={() => setActiveChat(chat)}
//                   >
//                     <div className="font-semibold">{chat.id}</div>
//                     <div className="text-sm text-gray-500">
//                       {chat.timestamp}
//                     </div>
//                     <div className="text-sm">{chat.preview}</div>
//                   </div>
//                 ))}
//               </div>
//             </div>
//             {/* Main Chat Area */}
//             <div className="flex-1 flex flex-col">
//               <div className="p-4 border-b border-gray-300 flex justify-between items-center">
//                 <div className="text-lg font-semibold">
//                   {activeChat?.id || "Chat"}
//                 </div>
//                 <div className="flex space-x-2">
//                   <button className="text-green-500">Accept</button>
//                   <button className="text-red-500">Reject</button>
//                 </div>
//               </div>
//               <div className="flex-1 p-4 overflow-y-auto">
//                 {activeChat?.messages.map((msg, index) => (
//                   <div
//                     key={index}
//                     className={`p-4 rounded mb-4 ${
//                       msg.sentByUser
//                         ? "bg-yellow-200 text-right"
//                         : "bg-gray-200"
//                     }`}
//                   >
//                     <div className="text-sm">{msg.text}</div>
//                     <div className="text-xs text-gray-500 text-right">
//                       {msg.timestamp}
//                     </div>
//                   </div>
//                 ))}
//               </div>
//               <div className="p-4 border-t border-gray-300 flex items-center">
//                 <input
//                   type="text"
//                   placeholder="Type here..."
//                   className="flex-1 p-2 border border-gray-300 rounded"
//                 />
//                 <button className="ml-2 text-gray-500">
//                   <i className="fas fa-paper-plane"></i>
//                 </button>
//               </div>
//             </div>
//           </section>
//         </div>
//       </div>
//       <Footer />
//     </>
//   );
};

export default ChatApp;
