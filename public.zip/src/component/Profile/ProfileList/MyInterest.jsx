import React, { useState, useEffect } from "react";
import "./ShortListedProfile.css";
import RequestCard from "./RequestCard";
import { FaChevronLeft, FaChevronRight, FaChevronDown } from "react-icons/fa";
import { useAuth } from "../../Layout/AuthContext";
import styles from "./RequestCard.module.css";
import pro from "../../../assets/images/blurimage.png";

export function InterestImageContainer({ profile, status, activeButton }) {
  const { updateData } = useAuth();

  const handlePhotoReq = async (profileId) => {
    try {
      console.log(profileId);
      let route = "profile/photoRequest";
      await updateData(route, profileId);
    } catch (error) {
      console.error("Error sending photo request:", error);
    }
  };

  if (!profile?.filesId?.photos || profile?.filesId?.photos?.length === 0) {
    return (
      <div
        className="image-container"
        style={{ position: "relative", width: "100%", height: "14rem" }}
      >
        <img
          src={pro}
          className="img-fluid m-auto"
          alt="Profile"
          style={{
            width: "100%",
            height: "100%",
            objectFit: "cover",
            objectPosition: "top",
          }}
        />
        <div
          className={styles.vipSection}
          style={{
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            textAlign: "center",
          }}
        >
          <p className="m-0 mb-1">Send request for photos</p>
          <button
            className={styles.ctaButton}
            onClick={() => handlePhotoReq(profile?._id)}
          >
            Request now
          </button>
        </div>
      </div>
    );
  }

  return (
    <div
      style={{
        position: "relative",
        width: "100%",
        height: "14rem",
        overflow: "hidden",
      }}
    >
      {profile?.filesId?.photos?.map((photo, index) => (
        <img
          key={photo._id}
          src={photo.url}
          className={`img-fluid m-auto ${
            index === 0 ? "visible-image" : "hidden-image"
          }`}
          alt="Profile"
          style={{
            position: "absolute",
            top: 0,
            left: 0,
            width: "100%",
            height: "100%",
            objectFit: "cover",
            objectPosition: "top",
            zIndex: index === 0 ? 1 : 0,
            opacity: index === 0 ? 1 : 0,
            transition: "opacity 0.5s ease",
          }}
        />
      ))}
    </div>
  );
}

function MyInterest() {
  const [activeTab, setActiveTab] = useState("requestSent");
  const { fetchUserData } = useAuth();

  const [loading, setLoading] = useState(true);
  const [sortCriteria, setSortCriteria] = useState("");
  const [profiles, setProfiles] = useState([]);
  const [data, setData] = useState({ reqSent: [], reqReceived: [] });
  const [error, setError] = useState(null);

  const profilesPerPage = 4;
  const [currentPage, setCurrentPage] = useState(1);

  const totalPages = Math.ceil(profiles?.length / profilesPerPage);

  const fetchData = async () => {
    try {
      setLoading(true);
      setError(null);
      const route = "profile/myrequests";
      const data = await fetchUserData(route);

      if (!data || !data.reqSent || !data.reqReceived) {
        throw new Error("Invalid data format");
      }

      setData(data);
      setProfiles(data.reqSent);
    } catch (err) {
      console.error("Error fetching data:", err);
      setError("An error occurred while fetching data. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const getProfilesForCurrentPage = () => {
    const startIdx = (currentPage - 1) * profilesPerPage;
    return profiles?.slice(startIdx, startIdx + profilesPerPage);
  };

  const handlePrevPage = () => {
    if (currentPage > 1) setCurrentPage(currentPage - 1);
  };

  const handleNextPage = () => {
    if (currentPage < totalPages) setCurrentPage(currentPage + 1);
  };

  const handlePageClick = (page) => {
    setCurrentPage(page);
  };

  const sortProfiles = (criteria) => {
    const sortedProfiles = [...profiles].sort((a, b) => {
      if (criteria === "age") return a.age - b.age;
      return 0;
    });
    setProfiles(sortedProfiles);
    setSortCriteria(criteria);
  };

  const switchTab = (tab) => {
    // console.log("Switching tab to:", tab);
    setActiveTab(tab);
    const newProfiles = tab === "requestSent" ? data.reqSent : data.reqReceived;
    console.log("New profiles set:", newProfiles);
    setProfiles(newProfiles);
    setCurrentPage(1);
  };

  useEffect(() => {
    fetchData();
  }, []);

  if (loading) {
    return <div className="profileContainer">Loading...</div>;
  }

  return (
    <div className="profileContainer">
      <div className="profileListHeader">
        <div className="pagetitle">My Interests</div>
        <div className="filters">
          <div
            className="filterItem d-flex justify-content-between"
            onClick={() => sortProfiles("age")}
          >
            <span>Age</span>
            <span>
              <FaChevronDown />
            </span>
          </div>
        </div>
      </div>

      <div className="row m-0 mb-1 p-0 bg-white">
        <div className="col-9 d-flex p-0">
          {["requestSent", "requestReceived"].map((tab) => (
            <div
              key={tab}
              onClick={() => switchTab(tab)}
              style={{
                backgroundColor: activeTab === tab ? "#991c1c" : "transparent",
                color: activeTab === tab ? "white" : "black",
                cursor: "pointer",
                alignContent: "center",
                padding: "0.7rem 1.5rem",
                fontFamily: "Open Sans, sans-serif",
                fontWeight: "600",
                fontSize: "clamp(10px, 2vw, 14px)",
              }}
            >
              {tab === "requestSent" ? "Request Sent" : "Request Received"}
            </div>
          ))}
        </div>
        <div className="col-3 p-0 p-sm-2" style={{ alignContent: "center" }}>
          <select
            className="form-select form-select-lg m-0"
            style={{
              color: "rgba(97, 97, 97, 1)",
              borderRadius: "0%",
              border: "1px solid rgba(97, 97, 97, 1)",
              padding: "0.5rem 1.5rem",
              fontFamily: "Open Sans, sans-serif",
              fontWeight: "600",
              fontSize: "clamp(12px, 2vw, 14px)",
              outline: "none",
            }}
            aria-label=".form-select-lg example"
          >
            <option value="all">All request</option>
            <option value="pending">Pending</option>
            <option value="accepted">Accepted</option>
            <option value="rejected">Rejected</option>
          </select>
        </div>
      </div>

      <div className="row m-0 p-0">
        {getProfilesForCurrentPage().length === 0 ? (
          <div className="pagetitle text-center">No Profiles Found</div>
        ) : (
          getProfilesForCurrentPage().map((profile) => (
            <RequestCard
              fetchData={fetchData}
              key={profile._id}
              profile={profile?.userId}
              status={profile?.status}
              activeTab={activeTab}
              ProfileImagerender={InterestImageContainer}
              handlecheck={() =>
                setProfiles(profiles.filter((p) => p._id !== profile._id))
              }
            />
          ))
        )}
      </div>

      <div className="d-flex align-items-center justify-content-center mt-3">
        <div className="d-flex align-items-center gap-2">
          <button
            className="btn"
            onClick={handlePrevPage}
            disabled={currentPage === 1}
          >
            <FaChevronLeft />
          </button>
          {Array.from({ length: totalPages }).map((_, index) => (
            <button
              key={index}
              className={`btn rounded-circle px-3 fw-bold ${
                currentPage === index + 1 ? "btn-danger text-white" : "bg-white"
              }`}
              onClick={() => handlePageClick(index + 1)}
            >
              {index + 1}
            </button>
          ))}
          <button
            className="btn"
            onClick={handleNextPage}
            disabled={currentPage === totalPages}
          >
            <FaChevronRight />
          </button>
        </div>
      </div>
    </div>
  );
}

export default MyInterest;
